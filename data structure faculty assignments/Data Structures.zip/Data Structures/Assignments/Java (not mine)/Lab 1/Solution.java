import java.io.*;
import java.util.*;
import java.text.*;
import java.math.*;
import java.util.regex.*;
import java.util.Scanner;

interface ICalculator {
    
	/**
	* Adds given two numbers
	* @param x first number
	* @param y second number
	* @return the sum of the two numbers
	*/
	 int add(int x,int y);
	/**
	* Divides two numbers
	* @param x first number
	* @param y second number
	* @return the division result
	*/
	float divide(int x,int y);
}

public class Calculator implements ICalculator{
  /* Implement your calculator class here*/

    public static void main(String[] args){
        
        Scanner Input = new Scanner(System.in);
        
        Calculator calc = new Calculator(); 
        
        int x = Input.nextInt();
        
        String operation = Input.next();
        
        int y = Input.nextInt();
        
         if(operation.equals("+")) {
             
            System.out.println(calc.add(x,y));
             
        } 
        else {
            if(y == 0) {
                System.out.println("Error");
            } 
            else {
                System.out.println(calc.divide(x,y));
            }
        }
    } 
    public int add(int x,int y) {
        return x + y ;
    }

    public float divide(int x,int y) {
        return (float) x/y ;
    }
}
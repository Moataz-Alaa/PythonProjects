import java.io.*;
import java.util.*;
import java.text.*;
import java.math.*;
import java.util.regex.*;


interface ILinkedList {
/**
* Inserts a specified element at the specified position in the list.
* @param index
* @param element
*/
public void add(int index, Object element);
/**
* Inserts the specified element at the end of the list.
* @param element
*/
public void add(Object element);
/**
* @param index
* @return the element at the specified position in this list.
*/
public Object get(int index);

/**
* Replaces the element at the specified position in this list with the
* specified element.
* @param index
* @param element
*/
public void set(int index, Object element);
/**
* Removes all of the elements from this list.
*/
public void clear();
/**
* @return true if this list contains no elements.
*/
public boolean isEmpty();
/**
* Removes the element at the specified position in this list.
* @param index
*/
public void remove(int index);
/**
* @return the number of elements in this list.
*/
public int size();
/**
* @param fromIndex
* @param toIndex
* @return a view of the portion of this list between the specified fromIndex and toIndex, inclusively.
*/
public ILinkedList sublist(int fromIndex, int toIndex);
/**
* @param o
* @return true if this list contains an element with the same value as the specified element.
*/
public boolean contains(Object o);
}

class Node {
    private Object element;
    private Node next;
    
    Node(Object e, Node n) {
        this.element = e;
        this.next = n;
    }
    /***
     * @return element stored
      */
    public Object getElement() {
        return this.element;
    }
    /**
     * sets the value of the element
     * @param e element to be stored
     */
    public void setElement(Object e) {
        this.element = e;
    }

    /**
     *
     * @return the next node
     */
    public Node getNext() {
        return this.next;
    }
    /**
 * connects the current node to the given node 
 * @param n next node 
 */
    public void setNext(Node n) {
        this.next = n;
    }
}

class SingleLinkedList implements ILinkedList {
    int size;
    Node header;
    Node tail;

    // constructor
    SingleLinkedList() {
        size = 0;
        header = null;
        tail = null;
    }

    // adds to certain index
    public void add(int index, Object element) {
        int i = 0;
        Node p = header;
        if (index >= size || index < 0) {
            System.out.println("Error");
            System.exit(0);
        }
        while (p != null) {
            if (index == 0) // addition from start
            {
                Node e = new Node(element, header);
                header = e;
                size = size + 1;
                break;
            } else {
                if (i + 1 == index) {
                    // then p now is the one before the added element
                    Node e = new Node(element, p.getNext());
                    // connect the pointer of the previous to the new element
                    p.setNext(e);
                    size = size + 1;
                    break;
                } else {
                    i += 1;
                    p = p.getNext();
                }

            }

        }

    }

    // adds to the end
    public void add(Object element) {
        Node e = new Node(element, null);
        // if it's empty
        if (header == null) {
            header = e;
            tail = e;
            size += 1;
        } else {
            tail.setNext(e);
            tail = e;
            size = size + 1;
        }
    }
    // gets object
    public Object get(int index) {
        Node p = header;
        int i = 0;
        if (p == null || index < 0 || index >= size) {
            System.out.println("Error");
            System.exit(0);
        }
        while (p != null) {
            if (i == index) {
                return p.getElement();
            } else {
                p = p.getNext();
                i += 1;
            }
        }
        return null;
    }
    // sets object
    public void set(int index, Object element) {

        Node p = header;
        if (p == null || index < 0 || index >= size) {
            System.out.println("Error");
            System.exit(0);
        }
        int i = 0;
        while (p != null) {
            if (i == index) {
                p.setElement(element);
                break;
            } else {
                p = p.getNext();
                i += 1;
            }
        }
    }

    //
    public void clear() {
        header = null;
        tail = null;
        size = 0;
    }

    //
    public boolean isEmpty() {
        return size == 0;
    }

    //
    public void remove(int index) {

        if (index > size() - 1 || size == 0 || (size == 1 && index != 0) || index < 0) {
            System.out.println("Error");
            System.exit(0);
        }

        if (size == 1 && index == 0) {
            clear();
        } else {
            if (index == 0) {
                header = header.getNext();
                size = size - 1;
            } else {
                int i = 0;
                Node p = header;
                while (p.getNext() != null) {
                    if (i + 1 == index) {
                        p.setNext((p.getNext()).getNext());
                        size = size - 1;
                        break;
                    } else {
                        p = p.getNext();
                        i = i + 1;
                    }
                }
            }
        }
    }

    //
    public int size() {
        return size;
    }

    //
    public ILinkedList sublist(int fromIndex, int toIndex) {
        SingleLinkedList sub = new SingleLinkedList();
        Node p = header;
        int i = 0;
        int temp;
        if (p == null || toIndex < fromIndex || toIndex < 0 || fromIndex < 0 || toIndex >= size || fromIndex >= size) {
            System.out.println("Error");
            System.exit(0);
        }
        while (p != null) {
            if (i == fromIndex)
                sub.header = p;
            if (i == toIndex) {
                sub.tail = p;
                temp = toIndex - fromIndex + 1;
                sub.size = temp;
                sub.tail.setNext(null);
                break;
            }
            p = p.getNext();
            i += 1;
        }
        return sub;
    }

    //
    public boolean contains(Object o) {
        boolean found = false;
        Node p = header;
        if (p == null) {
            System.out.println("Error");
            System.exit(0);
        }
        while (!found && p != null) {
            if (p.getElement() == o) {
                found = true;
            } else {
                p = p.getNext();
            }
        }
        if (found) {
            return true;
        } else {
            return false;
        }
    }

    public String print() {
        String out="";
        out = out + "[";
        Node p = header;
        int i = 0;
        while (p != null) {
            out = out + p.getElement();
            i++;
            p = p.getNext();
            if (i < size) {
                out = out +", ";
            }
        }
        out = out + "]";
        return out;
    }
}

interface IStack {
  
  /*** Removes the element at the top of stack and returnsthat element.
  * @return top of stack element, or through exception if empty
  */
  
  public Object pop();
  
  /*** Get the element at the top of stack without removing it from stack.
  * @return top of stack element, or through exception if empty
  */
  
  public Object peek();
  
  /*** Pushes an item onto the top of this stack.
  * @param object to insert*
  */
  
  public void push(Object element);
  
  /*** Tests if this stack is empty
  * @return true if stack empty
  */
  public boolean isEmpty();
  
  /**
   * @return size of the stack
   */
  public int size();
}

class MyStack implements IStack {
    private SingleLinkedList stk;

    MyStack() {
        stk = new SingleLinkedList();
    } // Constructor

    // POP
    // returns the element on top of the stack and removes it
    public Object pop() {
        if (stk.isEmpty())
            throw new NullPointerException();
        else {
            Object outObject = stk.get(0);
            stk.remove(0);
            return outObject;
        }
    }

    // PEEK
    // returns the element on top of the stack without removing it
    public Object peek() {
        if (stk.isEmpty())
            throw new NullPointerException();
        else
            return stk.get(0);
    }

    // PUSH
    // pushes an item on top of the stack
    public void push(Object element) {
        if (stk.isEmpty()) {
            stk.add(element);
        } else {
            stk.add(0, element);
        }
    }

    // ISEMPTY
    // checks if it is empty
    public boolean isEmpty() {
        return stk.isEmpty();
    }

    // SIZE
    public int size() {
        return stk.size();
    }
    
    /**
     * prints the stack
     */
    public void print() {
        System.out.println(stk.print());
    }
    
}

interface IExpressionEvaluator {
  
/**
* Takes a symbolic/numeric infix expression as input and converts it to
* postfix notation. There is no assumption on spaces between terms or the
* length of the term (e.g., two digits symbolic or numeric term)
*
* @param expression infix expression
* @return postfix expression
*/
  
public String infixToPostfix(String expression);
  
  
/**
* Evaluate a postfix numeric expression, with a single space separator
* @param expression postfix expression
* @return the expression evaluated value
*/
  
public int evaluate(String expression);

}


public class Evaluator implements IExpressionEvaluator {
    int a;
    int b;
    int c;

    /**
     * Sets the values of the 3 constants a, b and c used in the expressions
     * 
     * @param c1 value assigned to a and will be used to evaluate the expression
     * @param c2 value assigned to b and will be used to evaluate the expression
     * @param c3 value assigned to c and will be used to evaluate the expression
     */
    public void setValues(int c1, int c2, int c3) {
        this.a = c1;
        this.b = c2;
        this.c = c3;
    }

    /**
     * 
     * @param op the operator symbol +, (), - , * , / or ^
     * @return a number based on the precedence and the priority of execution. this
     *         function will be used to compare two operators to determine the order
     *         of operations .The function throws runtime exception in case of an
     *         unexpected operator
     */
    public int precedence(char op) {
        if (op == '+' || op == '-')
            return 1;
        else if (op == '*' || op == '/')
            return 2;
        else if (op == '^')
            return 3;
        else if (op == '(')
            return 4;
        else if (op == ')')
            return 0;
        else
            throw new RuntimeException();
    }

    /**
     * function used to calculate each simple operation that contains two operands
     * and one operator the function considers the result is 0 for each a^b where b
     * is negative number -
     * 
     * @param op operator
     * @param x  first operand
     * @param y  second operand
     * @return result of the given operation
     */
    public int calculate(char op, int x, int y) {
        switch (op) {
        case '+':
            return x + y;
        case '/':
            if (y == 0)
                throw new RuntimeException();
            else
                return x / y;
        case '*':
            return x * y;
        case '-':
            return x - y;
        case '^':
            if (y < 0)
                return 0;
            else
                return (int) Math.pow(x, y);
        default:
            throw new RuntimeException();
        }
    }

    /**
     * function responsible to return value of each symbol which will be used for
     * evaluation
     * 
     * @param x character whose value is requested
     * @return value of that character
     */
    public int getValue(char x) {
        switch (x) {
        case 'a':
            return a;
        case 'b':
            return b;
        case 'c':
            return c;
        default:
            throw new RuntimeException();
        }
    }
    public String infixToPostfix(String expression) {
        MyStack opStack = new MyStack();
        String res = "";
        int openedP = 0;

        for (int i = 0; i < expression.length(); i++) {
            char current = expression.charAt(i);
            // check if operand
            if (Character.isLetter(current)) {
                res = res + current;
                if (i > 0) {
                    // check if there is two successive letters
                    if (Character.isLetter(expression.charAt(i - 1)))
                        throw new RuntimeException();
                }
            }
            // check if operator
            // if open paranthesis
            else if (current == '(') {
                // put it in the stack
                opStack.push(current);
                openedP++;
            }

            else if (current == ')') {
                // if closed par.
                openedP--;
                // empty the stack till the open
                while (!opStack.isEmpty() && ((char) opStack.peek() != '('))
                    res = res + opStack.pop();
                // one '(' sho
                if (!opStack.isEmpty())
                    opStack.pop();
            }

            else if (!Character.isLetter(current)) {
                // handle operator in the start or the end
                if ((i == 0 && current != '-') || (i == expression.length() - 1))
                    throw new RuntimeException();
                if (i > 0) {
                    // check if there is two successive operators
                    if (!Character.isLetter(expression.charAt(i - 1)) && expression.charAt(i - 1) != '('
                            && expression.charAt(i - 1) != ')')
                        throw new RuntimeException();
                }
                // if the stack is empty we push the current
                if (opStack.isEmpty())
                    opStack.push(current);
                else {
                    while (!(opStack.isEmpty()) && (((char) opStack.peek()) != '(')
                            && (precedence(current) <= precedence((char) opStack.peek()))) {
                        res = res + opStack.pop();
                    }
                    opStack.push(current);
                }
            }
        }
        while (!opStack.isEmpty()) {
            res = res + opStack.pop();
        }

        if (openedP != 0)
            throw new RuntimeException();
        return res;
    }

    public int evaluate(String expression) {
        MyStack evStack = new MyStack();
        for (int i = 0; i < expression.length(); ++i) {
            char current = expression.charAt(i);
            // if operand push
            if (Character.isLetter(current)) {
                evStack.push(getValue(current));
            } else if (!Character.isLetter(current)) {
                int op1 = 0;
                int op2 = 0;
                // if there is a - in the end then its a sign
                try {
                    op2 = (int) evStack.pop();
                    op1 = (int) evStack.pop();
                } catch (Exception e) {
                    if (current != '-')
                        throw new RuntimeException();
                    op1 = 0;
                }
                int result = 0;
                try {
                    result = calculate(current, op1, op2);
                } catch (RuntimeException e) {
                    throw new RuntimeException();
                }

                evStack.push(result);
            }
        }
        int fin = (int) evStack.pop();
        return fin;
    }

    /**
     * Handles the input and part of the expression replaces all redundant --
     * expressions from the input string before processing reads and passes the
     * values to the function
     * 
     * @param args
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String exp = sc.nextLine().replace("^--", "^").replace("*--", "*").replace("/--", "/").replace("+--", "+")
                .replace("(--", "(");

        if (exp.startsWith("--"))
            exp = exp.replaceFirst("--", "");
        if (exp.contains("--"))
            exp = exp.replaceAll("--", "+");
        String strA = sc.nextLine().replaceAll("(a|b|c)=", "");
        String strB = sc.nextLine().replaceAll("(a|b|c)=", "");
        String strC = sc.nextLine().replaceAll("(a|b|c)=", "");
        int valA = Integer.parseInt(strA);
        int valB = Integer.parseInt(strB);
        int valC = Integer.parseInt(strC);
        sc.close();
        Evaluator Ev = new Evaluator();
        try {
            Ev.setValues(valA, valB, valC);
            String postfix = Ev.infixToPostfix(exp);
            int result = Ev.evaluate(postfix);
            System.out.println(postfix);
            System.out.println(result);
        } catch (RuntimeException e) {
            System.out.println("Error");
        }

    }
}
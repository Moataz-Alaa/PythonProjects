import java.io.*;
import java.util.*;
import java.text.*;
import java.math.*;
import java.util.regex.*;


interface ILinkedList {
/**
* Inserts a specified element at the specified position in the list.
* @param index
* @param element
*/
public void add(int index, Object element);
/**
* Inserts the specified element at the end of the list.
* @param element
*/
public void add(Object element);
/**
* @param index
* @return the element at the specified position in this list.
*/
public Object get(int index);

/**
* Replaces the element at the specified position in this list with the
* specified element.
* @param index
* @param element
*/
public void set(int index, Object element);
/**
* Removes all of the elements from this list.
*/
public void clear();
/**
* @return true if this list contains no elements.
*/
public boolean isEmpty();
/**
* Removes the element at the specified position in this list.
* @param index
*/
public void remove(int index);
/**
* @return the number of elements in this list.
*/
public int size();
/**
* @param fromIndex
* @param toIndex
* @return a view of the portion of this list between the specified fromIndex and toIndex, inclusively.
*/
public ILinkedList sublist(int fromIndex, int toIndex);
/**
* @param o
* @return true if this list contains an element with the same value as the specified element.
*/
public boolean contains(Object o);
}

class Node {
    private Object element;
    private Node next;
    
    Node(Object e, Node n) {
        this.element = e;
        this.next = n;
    }
    /***
     * @return element stored
      */
    public Object getElement() {
        return this.element;
    }
    /**
     * sets the value of the element
     * @param e element to be stored
     */
    public void setElement(Object e) {
        this.element = e;
    }

    /**
     *
     * @return the next node
     */
    public Node getNext() {
        return this.next;
    }
    /**
 * connects the current node to the given node 
 * @param n next node 
 */
    public void setNext(Node n) {
        this.next = n;
    }
}

class SingleLinkedList implements ILinkedList {
    int size;
    Node header;
    Node tail;

    // constructor
    SingleLinkedList() {
        size = 0;
        header = null;
        tail = null;
    }

    // adds to certain index
  public void add(int index, Object element) {
        int i = 0;
        Node p = header;
        if (index >= size || index < 0) {
            System.out.println("Error");
            System.exit(0);
        }
        while (p != null) {
            if (index == 0) // addition from start
            {
                Node e = new Node(element, header);
                header = e;
                size = size + 1;
                break;
            } else {
                if (i + 1 == index) {
                    // then p now is the one before the added element
                    Node e = new Node(element, p.getNext());
                    // connect the pointer of the previous to the new element
                    p.setNext(e);
                    size = size + 1;
                    break;
                } else {
                    i += 1;
                    p = p.getNext();
                }

            }

        }

    }

    // adds to the end
    public void add(Object element) {
        Node e = new Node(element, null);
        // if it's empty
        if (header == null) {
            header = e;
            tail = e;
            size += 1;
        } else {
            tail.setNext(e);
            tail = e;
            size = size + 1;
        }
    }
    // gets object
    public Object get(int index) {
        Node p = header;
        int i = 0;
        if (p == null || index < 0 || index >= size) {
            System.out.println("Error");
            System.exit(0);
        }
        while (p != null) {
            if (i == index) {
                return p.getElement();
            } else {
                p = p.getNext();
                i += 1;
            }
        }
        return null;
    }
   // sets object
    public void set(int index, Object element) {

        Node p = header;
        if (p == null || index < 0 || index >= size) {
            System.out.println("Error");
            System.exit(0);
        }
        int i = 0;
        while (p != null) {
            if (i == index) {
                p.setElement(element);
                break;
            } else {
                p = p.getNext();
                i += 1;
            }
        }
    }

    //
    public void clear() {
        header = null;
        tail = null;
        size = 0;
    }

    //
    public boolean isEmpty() {
        return size == 0;
    }

    //
    public void remove(int index) {

        if (index > size() - 1 || size == 0 || (size == 1 && index != 0) || index < 0) {
            System.out.println("Error");
            System.exit(0);
        }

        if (size == 1 && index == 0) {
            clear();
        } else {
            if (index == 0) {
                header = header.getNext();
                size = size - 1;
            } else {
                int i = 0;
                Node p = header;
                while (p.getNext() != null) {
                    if (i + 1 == index) {
                        p.setNext((p.getNext()).getNext());
                        size = size - 1;
                        break;
                    } else {
                        p = p.getNext();
                        i = i + 1;
                    }
                }
            }
        }
    }

    //
    public int size() {
        return size;
    }

    //
    public ILinkedList sublist(int fromIndex, int toIndex) {
        SingleLinkedList sub = new SingleLinkedList();
        Node p = header;
        int i = 0;
        int temp;
        if (p == null || toIndex < fromIndex || toIndex < 0 || fromIndex < 0 || toIndex >= size || fromIndex >= size) {
            System.out.println("Error");
            System.exit(0);
        }
        while (p != null) {
            if (i == fromIndex)
                sub.header = p;
            if (i == toIndex) {
                sub.tail = p;
                temp = toIndex - fromIndex + 1;
                sub.size = temp;
                sub.tail.setNext(null);
                break;
            }
            p = p.getNext();
            i += 1;
        }
        return sub;
    }
   //
    public boolean contains(Object o) {
        boolean found = false;
        Node p = header;
        if (p == null) {
            System.out.println("Error");
            System.exit(0);
        }
        while (!found && p != null) {
            if (p.getElement() == o) {
                found = true;
            } else {
                p = p.getNext();
            }
        }
        if (found) {
            return true;
        } else {
            return false;
        }
    }

    public String print() {
        String out="";
        out = out + "[";
        Node p = header;
        int i = 0;
        while (p != null) {
            out = out + p.getElement();
            i++;
            p = p.getNext();
            if (i < size) {
                out = out +", ";
            }
        }
        out = out + "]";
        return out;
    }
}

interface IStack {
  
  /*** Removes the element at the top of stack and returnsthat element.
  * @return top of stack element, or through exception if empty
  */
  
  public Object pop();
  
  /*** Get the element at the top of stack without removing it from stack.
  * @return top of stack element, or through exception if empty
  */
  
  public Object peek();
  
  /*** Pushes an item onto the top of this stack.
  * @param object to insert*
  */
  
  public void push(Object element);
  
  /*** Tests if this stack is empty
  * @return true if stack empty
  */
  public boolean isEmpty();
  
  public int size();
}

public class MyStack implements IStack {
 private SingleLinkedList stk;

    MyStack() {
        stk = new SingleLinkedList();
    } // Constructor

    // POP
    // returns the element on top of the stack and removes it
    public Object pop() {
        if (stk.isEmpty())
            throw new NullPointerException();
        else {
            Object outObject = stk.get(0);
            stk.remove(0);
            return outObject;
        }
    }
    // PEEK
    // returns the element on top of the stack without removing it
    public Object peek() {
        if (stk.isEmpty())
            throw new NullPointerException();
        else
            return stk.get(0);
    }

    // PUSH
    // pushes an item on top of the stack
    public void push(Object element) {
        if (stk.isEmpty()) {
            stk.add(element);
        } else {
            stk.add(0, element);
        }
    }

    // ISEMPTY
    // checks if it is empty
    public boolean isEmpty() {
        return stk.isEmpty();
    }

    // SIZE
    public int size() {
        return stk.size();
    }
    
    /**
     * prints the stack
     */
    public void print() {
        System.out.println(stk.print());
    }
    public static void main(String[] args) {
        try{
            Scanner read = new Scanner(System.in);
            MyStack S = new MyStack();
            String operation;
            String input = read.nextLine().replaceAll("\\[|\\]", "");
            String [] inputNoComma = input.split(", ");
            if(inputNoComma.length != 1 || !inputNoComma[0].isEmpty()){
                for(int i = inputNoComma.length - 1; i > -1; i--)
                    S.push(Integer.parseInt(inputNoComma[i]));
            }
            operation = read.nextLine();
            switch(operation){
                case "pop":
                     Object popped = S.pop();
                     S.print();
                     break;
                case "peek":
                     System.out.println(S.peek());
                     break;
                case "push":
                    int elem = read.nextInt();
                    S.push(elem);
                    S.print();
                    break;
                case "isEmpty":
                    if(S.isEmpty()) System.out.println("True");
                    else System.out.println("False");
                    break;
                case "size":
                    System.out.println(S.size());
                    break;
                default :
                    System.out.println("Error");
            }
       }
       catch (Exception e){System.out.println("Error");}
    }
}
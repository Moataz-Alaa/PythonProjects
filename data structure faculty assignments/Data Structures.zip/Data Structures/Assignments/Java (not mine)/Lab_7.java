import java.io.*;
import java.util.Scanner;
import java.awt.Point;

interface IStack {
    /**
    * Removes the element at the top of stack and returns that element.
    * @return top of stack element, or through exception if empty
    */
    public Object pop();
    /**
    * Get the element at the top of stack without removing it from stack.
    * @return top of stack element, or through exception if empty
    */
    public Object peek();
    /**
    * Pushes an item onto the top of this stack.
    * @param object to insert
    */
    public void push(Object element);
    /**
    * Tests if this stack is empty
    * @return true if stack empty
    */
    public boolean isEmpty();
    
    public int size();
}

interface IQueue {
    /**
    * Inserts an item at the queue front.
    */
    public void enqueue(Object item);
    /**
    * Removes the object at the queue rear and returns it.
    */
    public Object dequeue();
    /**
    * Tests if this queue is empty.
    */
    public boolean isEmpty();
    /**
    * @Returns the number of elements in the queue
    */
    public int size();
}

interface IMazeSolver {
    /*** Read the maze file, and solve it using Breadth FirstSearch*
    @param maze maze file* @return the coordinates of the found path from point’S’*to point ’E’ inclusive,
    or null if no path is found.*/
    public void solveBFS(java.io.File maze);
    /*** Read the maze file, and solve it using Depth FirstSearch*
    @param maze maze file* @return the coordinates of the found path from point’S’*to point ’E’ inclusive,
    or null if no path is found.*/
    public void solveDFS(java.io.File maze);
}

class ArrayStack implements IStack {
    
    public static final int CAPACITY = 1000;
    private int capacity;
    private int t = -1;
    private Object s[];
    private static Boolean error = false;
    
    ArrayStack(){
        this(CAPACITY);
    }
    
    ArrayStack(int cap){
        capacity = cap;
        s = new Object[capacity];
    }
    
    public int size(){
        return(t + 1);
    }
    
    public boolean isEmpty(){
        return (size() == 0);
    }
    
    public void push(Object element){
        if (size() == capacity){
            error = true;
            return;
        }
        s[++t] = element;
    }
    
    
    public Object pop(){
        if (isEmpty()){
            error = true;
            return null;
        }
        Object element = s[t];
        s[t--] = null;
        return element;
    }
    
    public Object peek(){
        if (isEmpty()){
            error = true;
            return null;
        }
        return s[t];
    }
    
    public void print(){
        if (isEmpty()){
            System.out.println("[]");
        } else {
            System.out.print("[");
            for (int i = 0; i < t; i++){
                System.out.print(s[t - i]);
                System.out.print(", ");
            }
            System.out.print(s[0]);
            System.out.println("]");
        }
    }
}

class ArrayQueue implements IQueue {
    
    public static final int CAPACITY = 1000;
    private int n;
    private int f, r = 0;
    private Object s[];
    private static Boolean error = false;
    
    public ArrayQueue(){
        this(CAPACITY);
    }
    
    public ArrayQueue(int cap){
        n = cap;
        s = new Object[n];
    }
    
    public int size(){
        return((n - f + r) % n);
    }
    
    public boolean isEmpty(){
        return(f == r);
    }
    
    public void enqueue(Object element){
        if (size() == n - 1){
            error = true;
            return;
        }
        s[r++] = element;
        r %= n;
    }
    
    public Object dequeue(){
        if (isEmpty()){
            error = true;
            return null;
        }
        Object element = s[f];
        s[f++] = null;
        f %= n;
        return element;
    }
    
    public void print(){
        if (isEmpty()){
            System.out.println("[]");
        } else {
            System.out.print("[");
            for (int i = 0; i < size()-1; i++){
                System.out.print(s[Math.abs(r - 1) % n - i]);
                System.out.print(", ");
            }
            System.out.print(s[f]);
            System.out.println("]");
        }
    }
}

public class Main implements IMazeSolver{
	public static void main(String[] args) {
	    File maze = new File("Test.txt");
	    Main mySolver = new Main();
	    Scanner sc = new Scanner(System.in);
	    
	    System.out.println("Maze Solver:\n");
	    System.out.println("Enter 0, 1 or 2");
	    System.out.println("0. Exit");
	    System.out.println("1. Breadth First Search (BFS)");
	    System.out.println("2. Depth First Search (DFS)");
	    System.out.println();
	    
	    String option = "";
	    
	    while (true){
	        option = sc.nextLine();
	        if (option.equals("0")){
	            System.out.println("Exiting...");
	            return;
	        } else if (option.equals("1")){
	            mySolver.solveBFS(maze);
	            System.out.println();
	        } else if (option.equals("2")){
	            mySolver.solveDFS(maze);
	            System.out.println();
	        } else {
	            System.out.println("Please, Enter a valid option");
	        }
	    }
	}

    public void solveBFS(java.io.File maze){
        int rows = 0;
        int cols = 0;
        java.awt.Point start = null;
        java.awt.Point end = null;
        String[][] MazeArr;
        
	    try{
	        
            String st;
            int[] dim = new int[2];
            BufferedReader br = new BufferedReader(new FileReader(maze));
            
            st = br.readLine();
            String[] dimStr = st.split(" ");
            
            rows = Integer.parseInt(dimStr[0]);
            cols = Integer.parseInt(dimStr[1]);
            
            MazeArr = new String[rows][cols];

            for (int i = 0; i < rows; i++){
                st = br.readLine();
                MazeArr[i] = st.split("");
                for (int j = 0; j < cols; j++){
                    if (MazeArr[i][j].equals("S"))
                        start = new java.awt.Point(j, i);
                    if (MazeArr[i][j].equals("E"))
                        end = new java.awt.Point(j, i);
                }
            }
	    } catch (Exception e){
            e.printStackTrace();
	        return;
	    }

        boolean[][] visited = new boolean[rows][cols];
        boolean first = true;
        
        ArrayQueue myQueue = new ArrayQueue();
        ArrayStack revPath = new ArrayStack();
        ArrayStack path = new ArrayStack();
        myQueue.enqueue(start);

        while (myQueue.size() > 0){
            java.awt.Point point = (java.awt.Point)myQueue.dequeue();

            if (!MazeArr[point.y][point.x].equals("E")){
                if(!visited[point.y][point.x]){
                    revPath.push(point);
                    visited[point.y][point.x] = true;
                    int[][] points = {{point.y, Math.min(point.x+1, cols-1)}, {Math.max(point.y-1,0), point.x}, 
                        {point.y, Math.max(point.x-1,0)}, {Math.min(point.y+1, rows-1), point.x}};
                    
                    for(int[] p : points){
                        if (!visited[p[0]][p[1]] && !MazeArr[p[0]][p[1]].equals("#"))
                            myQueue.enqueue(new java.awt.Point(p[1], p[0]));
                    }
                }
            } else {
                revPath.push(point);
                break;
            }
        }
        
        java.awt.Point point = (java.awt.Point)revPath.pop();
        if (!MazeArr[point.y][point.x].equals("E")){
            System.out.println("No solution to this maze");
            return;
        }
        
        path.push(point);
        
        while(revPath.size() > 0){
            java.awt.Point peek = (java.awt.Point)revPath.peek();
            if ((Math.abs(point.x - peek.x) == 1 && point.y == peek.y) || (Math.abs(point.y - peek.y) == 1 && point.x == peek.x)){
                point = (java.awt.Point)revPath.pop();
                path.push(point);
            } else {
                revPath.pop();    
            }
        }
        
        point = (java.awt.Point)path.pop();
        System.out.print("BFS: {" + point.y + ", " + point.x + "}");
        
        while(path.size() > 0){
            point = (java.awt.Point)path.pop();
            System.out.print(", {" + point.y + ", " + point.x + "}");
        }
    }
    
    public void solveDFS(java.io.File maze){
        int rows = 0;
        int cols = 0;
        java.awt.Point start = null;
        java.awt.Point end = null;
        String[][] MazeArr;
        
	    try{
	        
            String st;
            int[] dim = new int[2];
            BufferedReader br = new BufferedReader(new FileReader(maze));
            
            st = br.readLine();
            String[] dimStr = st.split(" ");
            
            rows = Integer.parseInt(dimStr[0]);
            cols = Integer.parseInt(dimStr[1]);
            
            MazeArr = new String[rows][cols];

            for (int i = 0; i < rows; i++){
                st = br.readLine();
                MazeArr[i] = st.split("");
                for (int j = 0; j < cols; j++){
                    if (MazeArr[i][j].equals("S"))
                        start = new java.awt.Point(j, i);
                    if (MazeArr[i][j].equals("E"))
                        end = new java.awt.Point(j, i);
                }
            }
	    } catch (Exception e){
	        e.printStackTrace();
	        return;
	    }

        boolean[][] visited = new boolean[rows][cols];
        boolean first = true;
        
        ArrayStack myStack = new ArrayStack();
        ArrayStack revPath = new ArrayStack();
        ArrayStack path = new ArrayStack();
        myStack.push(start);

        while (myStack.size() > 0){
            java.awt.Point point = (java.awt.Point)myStack.pop();

            if (!MazeArr[point.y][point.x].equals("E")){
                if(!visited[point.y][point.x]){
                    revPath.push(point);
                    visited[point.y][point.x] = true;
                    int[][] points = {{point.y, Math.min(point.x+1, cols-1)}, {Math.max(point.y-1,0), point.x}, 
                        {point.y, Math.max(point.x-1,0)}, {Math.min(point.y+1, rows-1), point.x}};
                    
                    for(int[] p : points){
                        if (!visited[p[0]][p[1]] && !MazeArr[p[0]][p[1]].equals("#"))
                            myStack.push(new java.awt.Point(p[1], p[0]));
                    }
                }
            } else {
                revPath.push(point);
                break;
            }
        }

        java.awt.Point point = (java.awt.Point)revPath.pop();
        if (!MazeArr[point.y][point.x].equals("E")){
            System.out.println("No solution to this maze");
            return;
        }
        
        path.push(point);
        
        while(revPath.size() > 0){
            java.awt.Point peek = (java.awt.Point)revPath.peek();
            if ((Math.abs(point.x - peek.x) == 1 && point.y == peek.y) || (Math.abs(point.y - peek.y) == 1 && point.x == peek.x)){
                point = (java.awt.Point)revPath.pop();
                path.push(point);
            } else {
                revPath.pop();    
            }
        }
        
        point = (java.awt.Point)path.pop();
        System.out.print("DFS: {" + point.y + ", " + point.x + "}");
        
        while(path.size() > 0){
            point = (java.awt.Point)path.pop();
            System.out.print(", {" + point.y + ", " + point.x + "}");
        }
    }
}
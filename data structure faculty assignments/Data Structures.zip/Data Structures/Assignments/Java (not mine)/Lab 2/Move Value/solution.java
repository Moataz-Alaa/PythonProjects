import java.io.*;
import java.util.*;
import java.text.*;
import java.math.*;
import java.util.regex.*;

public class Solution {
	public int[] moveValue(int[] array, int value) {
    	int[] arr2 = new int[array.length];
        int counter = 0 ;
        int i;
        for(i=0;i<array.length;i++)
        {
            if(array[i]!=value)
            {
                arr2[counter++]=array[i];
            }
        }
        for (int j=counter;j<array.length;j++)
        {
            arr2[counter++]=value;
        }
        return arr2;
    }
    public static void main(String[] args) {
        Scanner sc= new Scanner(System.in);
        String line=sc.nextLine().replaceAll("\\[|\\]","");
        String[] s= line.split(", ");
        int value=sc.nextInt();
        Solution obj = new Solution();
        int[] arr= new int[s.length];
        sc.close();
        if(s.length ==1 && s[0].isEmpty())
        {
            arr=new int[] {};
        }
        else
        {
            
            int counter = 0 ;
            for(String c:s)
            {
                arr[counter++] = Integer.parseInt(c);
            }
            arr = obj.moveValue(arr,value);
        }
        System.out.print("[");
          for(int i = 0; i < arr.length; ++i) {
            System.out.print(arr[i]);
            if(i != s.length - 1)
              System.out.print(", ");
        }
        System.out.print("]");
        
    }
}
import java.io.*;
import java.util.*;
import java.text.*;
import java.math.*;
import java.util.regex.*;

public class Solution {
	public int[] sumEvenOdd(int[] array) {
    	int Final_Result[] = new int[2];
        Final_Result[0] = 0 ;
        Final_Result[1] = 0 ;
        for (int element:array)
        {
            if ( element % 2 == 0 )
                Final_Result[0] += element ;
            else
                Final_Result[1] += element ;
        }
        return Final_Result ;
    }
    public static void main(String[] args) {
       Scanner sc = new Scanner(System.in) ;
        String input=sc.nextLine().replaceAll("\\[|\\]","");
        String[] strIn= input.split(", ");
        int[] arr = new int[strIn.length];
        int[] sum = new int[2];
        Solution s = new Solution();
        int counter = 0;
        if(strIn.length==1 && strIn[0].isEmpty())
        {
            sum[0] = 0;
            sum[1] = 0;
        }
        else 
        {
            for (String st:strIn)
            {
                arr[counter++]=Integer.parseInt(st) ;
            }
            sum = s.sumEvenOdd(arr) ;
        }
            
        System.out.println("[" + sum[0] + ", " + sum[1] + "]") ;
    }
}
import java.io.*;
import java.util.*;
import java.text.*;
import java.math.*;
import java.util.regex.*;

public class Solution {
	public int[][] transpose(int[][] array) {
    	int[][] result = new int[array.length][array.length];
        for (int i=0 ; i<array.length ; i++)
        {
            for(int j=0 ; j<array.length ; j++)
            {
                result[i][j]=array[j][i];
            }
        }
            
        return result;
    }
    public static void main(String[] args) {
        Scanner sc= new Scanner(System.in);
        Solution sol=new Solution();
        String line=sc.nextLine();
        String[] arrays=line.split("\\]\\, \\[");
        
        for(int i=0;i<arrays.length;i++)
        {
            arrays[i]=arrays[i].replaceAll("\\[|\\]","");
        }
        String[][] elements = new String[arrays.length][]; 
        
        for(int i=0;i<arrays.length;i++)
        {
            elements[i]=arrays[i].split(", ");
        }
        
        int[][] arr=new int[arrays.length][arrays.length];
        if(arrays.length==1 && arrays[0].isEmpty())
        {
            System.out.print("[[]]");
            //arr=new int[][]{};
        }
        else {
            for(int i=0; i<arrays.length;i++)
            {
                int j=0;
                for(String s:elements[i])
                {
                    arr[i][j++]=Integer.parseInt(s);
                }
            }
        
        arr=sol.transpose(arr);

        System.out.print("[");
        for(int i=0;i<arr.length;i++)
        {
            System.out.print("[");
            for(int j=0;j<arr[i].length; j++) {
                System.out.print(arr[i][j]);
                if(j != arr[i].length-1)
                  System.out.print(", ");
            }
            System.out.print("]");
            if(i != arr.length-1)
                System.out.print(", ");
        }
        System.out.print("]");
        }
    }
}
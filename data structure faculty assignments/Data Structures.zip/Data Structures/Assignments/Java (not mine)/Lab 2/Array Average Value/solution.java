import java.io.*;
import java.util.*;
import java.text.*;
import java.math.*;
import java.util.regex.*;

public class Solution {
	public double average(int[] array) {
        double sum = 0 ;
        double counter = 0 ;
        for(int element:array){
            sum += element ;
            counter++ ;
        }
        if(array.length==0) 
            return 0;
        else 
            return sum/counter;
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String input=sc.nextLine().replaceAll("\\[|\\]","");
        String[] strIn = input.split(", ");
        int[] arr = new int[strIn.length];
        int counter = 0 ;
        double Answer ;
        if(strIn.length==1 && strIn[0].isEmpty())
            Answer = 0 ;
        else {
            for (String s:strIn)
             {
                 arr[counter++]=Integer.parseInt(s);
              }
            Solution s = new Solution();
            Answer= s.average(arr);
        }
        System.out.println(Answer);
    }
}
import java.io.*;
import java.util.*;
import java.text.*;
import java.math.*;
import java.util.regex.*;

public class Solution {
	public int fibonacci(int n) {
    	int f1 = 0 ;
        int f2 = 1 ;
        int f3 = 0 ;
        if(n==1)
            return f1;
        else if(n==2)
            return f2;
        else{
            int i=3;
            while(i<=n)
            {
                f3 = f2 + f1 ;
                f1 = f2 ;
                f2 = f3 ;
                i++ ;
            }
            return f3 ;
        }
    }
    public static void main(String[] args) {
        Scanner sc= new Scanner(System.in);
        int n=sc.nextInt();
        Solution s= new Solution();
        int fib=s.fibonacci(n);
        System.out.println(fib);
    }
}
import java.io.*;
import java.util.*;
import java.text.*;
import java.math.*;
import java.util.regex.*;

interface ILinkedList {
/**
* Inserts a specified element at the specified position in the list.
* @param index
* @param element
*/
public void add(int index, Object element);
/**
* Inserts the specified element at the end of the list.
* @param element
*/
public void add(Object element);
/**
* @param index
* @return the element at the specified position in this list.
*/
public Object get(int index);

/**
* Replaces the element at the specified position in this list with the
* specified element.
* @param index
* @param element
*/
public void set(int index, Object element);
/**
* Removes all of the elements from this list.
*/
public void clear();
/**
* @return true if this list contains no elements.
*/
public boolean isEmpty();
/**
* Removes the element at the specified position in this list.
* @param index
*/
public void remove(int index);
/**
* @return the number of elements in this list.
*/
public int size();
/**
* @param fromIndex
* @param toIndex
* @return a view of the portion of this list between the specified fromIndex and toIndex, inclusively.
*/
public ILinkedList sublist(int fromIndex, int toIndex);
/**
* @param o
* @return true if this list contains an element with the same value as the specified element.
*/
public boolean contains(Object o);
}

class Node {
    private Node prev;
    private Node next;
    private Object element;

    Node(Node p, Object e, Node n) {
        this.prev = p;
        this.element = e;
        this.next = n;
    }

    public Object getElement() {
        return this.element;
    }

    public void setElement(Object e) {
        this.element = e;
    }

    public Node getNext() {
        return this.next;
    }

    public void setNext(Node n) {
        this.next = n;
    }

    public Node getPrev() {
        return this.prev;
    }

    public void setPrev(Node n) {
        this.prev = n;
    }

}

public class DoubleLinkedList implements ILinkedList {

    int size;
    Node header;
    Node tail;

    DoubleLinkedList() {
        size = 0;
        header = null;
        tail = null;
    }

    public void add(int index, Object element) {
        int i = 0;
        Node p = header;
        if (index >= size || index < 0) {
            System.out.println("Error");
            System.exit(0);
        }
        while (p != null) {
            if (index == 0) // addition from start
            {
                Node e = new Node(null, element, header);
                header.setPrev(e);
                header = e;
                size = size + 1;
                break;
            } else {
                if (i == index) {
                    Node e = new Node(p.getPrev(), element, p);
                    Node q = e.getPrev();
                    q.setNext(e);
                    p.setPrev(e);
                    size = size + 1;
                    break;
                } else {
                    i += 1;
                    p = p.getNext();
                }

            }

        }

    }

    // adds to the end
    public void add(Object element) {
        Node e = new Node(tail, element, null);
        // if it's empty
        if (header == null) {
            header = e;
            tail = e;
            size += 1;
        } else {
            tail.setNext(e);
            tail = e;
            size = size + 1;
        }
    }
    // gets object
    public Object get(int index) {
        if (header == null || index < 0 || index >= size) {
            System.out.println("Error");
            System.exit(0);
        }
        if (index < size / 2) {
            Node p = header;
            int i = 0;
            while (p != null) {
                if (i == index) {
                    return p.getElement();
                } else {
                    p = p.getNext();
                    i += 1;
                }
            }
            return null;
        } else {
            Node p = tail;
            int i = size - 1;
            while (p != header) {
                if (i == index) {
                    return p.getElement();
                } else {
                    p = p.getPrev();
                    i -= 1;
                }
            }
            return null;
        }

    }
    // sets object
    public void set(int index, Object element) {

        if (header == null || index < 0 || index >= size) {
            System.out.println("Error");
            System.exit(0);
        }
        if (index < size / 2) {
            Node p = header;
            int i = 0;
            while (p != null) {
                if (i == index) {
                    p.setElement(element);
                    break;
                } else {
                    p = p.getNext();
                    i += 1;
                }
            }
        } else {
            Node p = tail;
            int i = size - 1;
            while (p != header) {
                if (i == index) {
                    p.setElement(element);
                    break;
                } else {
                    p = p.getPrev();
                    i -= 1;
                }
            }
        }

    }

    public void clear() {
        header = null;
        tail = null;
    }

    public boolean isEmpty() {
        return size == 0;
    }

    public void remove(int index) {

        if (index > size - 1 || size == 0 || (size == 1 && index != 0) || index < 0) {
            System.out.println("Error");
            System.exit(0);
        }

        if (size == 1 && index == 0) {
            clear();
        } else {
            if (index == 0) {
                header = header.getNext();
                size = size - 1;
            } else if (index == size - 1) {
                Node q = tail.getPrev();
                tail = q;
                tail.setNext(null);
                size -= 1;
            } else {
                int i = 0;
                Node p = header;

                while (p != null) {
                    if (i == index) {

                        Node q = p.getPrev();
                        Node r = p.getNext();

                        // q p r
                        q.setNext(r);
                        r.setPrev(q);
                        size = size - 1;
                        break;
                    } else {
                        p = p.getNext();
                        i = i + 1;
                    }
                }
            }
        }
    }

    public int size() {
        return size;
    }

    public ILinkedList sublist(int fromIndex, int toIndex) {
        DoubleLinkedList sub = new DoubleLinkedList();
        Node p = header;
        int i = 0;
        int temp;
        if (p == null || toIndex < fromIndex || toIndex < 0 || fromIndex < 0 || toIndex >= size || fromIndex >= size) {
            System.out.println("Error");
            System.exit(0);
        }
        while (p != null) {
            if (i == fromIndex)
                sub.header = p;
            if (i == toIndex) {
                sub.tail = p;
                temp = toIndex - fromIndex + 1;
                sub.size = temp;
                sub.tail.setNext(null);
                break;
            }
            p = p.getNext();
            i += 1;
        }
        return sub;
    }

    public boolean contains(Object o) {
        boolean found = false;
        Node p = header;
        if (p == null) {
            System.out.println("Error");
            System.exit(0);
        }
        while (!found && p != null) {
            if (p.getElement() == o) {
                found = true;
            } else {
                p = p.getNext();
            }
        }
        if (found) {
            return true;
        } else {
            return false;
        }
    }

    public void display() {
        System.out.print("[");
        Node p = header;
        int i = 0;
        while (p != null) {
            System.out.print(p.getElement());
            i++;
            p = p.getNext();
            if (i < size) {
                System.out.print(", ");
            }
        }
        System.out.print("]");
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String sin = sc.nextLine().replaceAll("\\[|\\]", "");
        String[] s = sin.split(", ");
        boolean emptyList = false;
        DoubleLinkedList l = new DoubleLinkedList();
        if (!(s.length == 1 && s[0].isEmpty())) {
            for (int i = 0; i < s.length; ++i)
                l.add(Integer.parseInt(s[i]));
        }
        String command = sc.nextLine();
        switch (command) {

        case "add":
            int num = sc.nextInt();
            l.add(num);
            l.display();
            break;

        case "addToIndex":
            int index = sc.nextInt();
            sc.nextLine();
            int value = sc.nextInt();
            l.add(index, value);
            l.display();
            break;

        case "get":
            int i = sc.nextInt();
            Object o = l.get(i);
            if (o == null)
                System.out.println("Error");
            else
                System.out.println((int) o);
            break;

        case "set":
            int index1 = sc.nextInt();
            sc.nextLine();
            int value1 = sc.nextInt();
            l.set(index1, value1);
            l.display();
            break;

        case "clear":
            l.clear();
            l.display();
            break;

        case "isEmpty":
            if (l.isEmpty())
                System.out.println("True");
            else
                System.out.println("False");
            break;

        case "remove":
            int index2 = sc.nextInt();
            l.remove(index2);
            l.display();
            break;

        case "sublist":
            int i1 = sc.nextInt();
            sc.nextLine();
            int i2 = sc.nextInt();
            DoubleLinkedList sub;
            sub = (DoubleLinkedList) l.sublist(i1, i2);
            sub.display();
            break;

        case "contains":
            int test = sc.nextInt();
            if (l.contains(test))
                System.out.println("True");
            else
                System.out.println("False");
            break;

        case "size":
            System.out.println(l.size());
            break;

        default:
            System.out.println("Error");
        }

    }

}
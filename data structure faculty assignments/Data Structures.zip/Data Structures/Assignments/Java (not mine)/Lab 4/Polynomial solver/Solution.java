import java.io.*;
import java.util.*;
import java.text.*;
import java.math.*;
import java.util.regex.*;

interface ILinkedList {
/**
* Inserts a specified element at the specified position in the list.
* @param index
* @param element
*/
public void add(int index, Object element);
/**
* Inserts the specified element at the end of the list.
* @param element
*/
public void add(Object element);
/**
* @param index
* @return the element at the specified position in this list.
*/
public Object get(int index);

/**
* Replaces the element at the specified position in this list with the
* specified element.
* @param index
* @param element
*/
public void set(int index, Object element);
/**
* Removes all of the elements from this list.
*/
public void clear();
/**
* @return true if this list contains no elements.
*/
public boolean isEmpty();
/**
* Removes the element at the specified position in this list.
* @param index
*/
public void remove(int index);
/**
* @return the number of elements in this list.
*/
public int size();
/**
* @param fromIndex
* @param toIndex
* @return a view of the portion of this list between the specified fromIndex and toIndex, inclusively.
*/
public ILinkedList sublist(int fromIndex, int toIndex);
/**
* @param o
* @return true if this list contains an element with the same value as the specified element.
*/
public boolean contains(Object o);
}

class Node {
    private Object element;
    private Node next;

    Node(Object e, Node n) {
        this.element = e;
        this.next = n;
    }

    public Object getElement() {
        return this.element;
    }

    public void setElement(Object e) {
        this.element = e;
    }

    public Node getNext() {
        return this.next;
    }

    public void setNext(Node n) {
        this.next = n;
    }
}


 class SingleLinkedList implements ILinkedList {
    int size;
    Node header;
    Node tail;

    // constructor
    SingleLinkedList() {
        size = 0;
        header = null;
        tail = null;
    }

    // adds to certain index
    public void add(int index, Object element) {
        int i = 0;
        Node p = header;
        if (index >= size || index < 0) {
            System.out.println("Error");
            System.exit(0);
        }
        while (p != null) {
            if (index == 0) // addition from start
            {
                Node e = new Node(element, header);
                header = e;
                size = size + 1;
                break;
            } else {
                if (i + 1 == index) {
                    // then p now is the one before the added element
                    Node e = new Node(element, p.getNext());
                    // connect the pointer of the previous to the new element
                    p.setNext(e);
                    size = size + 1;
                    break;
                } else {
                    i += 1;
                    p = p.getNext();
                }

            }

        }

    }

    // adds to the end
    public void add(Object element) {
        Node e = new Node(element, null);
        // if it's empty
        if (header == null) {
            header = e;
            tail = e;
            size += 1;
        } else {
            tail.setNext(e);
            tail = e;
            size = size + 1;
        }
    }

    // gets object
    public Object get(int index) {
        Node p = header;
        int i = 0;
        if (p == null || index < 0 || index >= size) {
            System.out.println("Error");
            System.exit(0);
        }
        while (p != null) {
            if (i == index) {
                return p.getElement();
            } else {
                p = p.getNext();
                i += 1;
            }
        }
        return null;
    }

    // sets object
    public void set(int index, Object element) {

        Node p = header;
        if (p == null || index < 0 || index >= size) {
            System.out.println("Error");
            System.exit(0);
        }
        int i = 0;
        while (p != null) {
            if (i == index) {
                p.setElement(element);
                break;
            } else {
                p = p.getNext();
                i += 1;
            }
        }
    }

    //
    public void clear() {
        header = null;
        tail = null;
    }

    //
    public boolean isEmpty() {
        return size == 0;
    }

    //
    public void remove(int index) {

        if (index > size() - 1 || size == 0 || (size == 1 && index != 0) || index < 0) {
            System.out.println("Error");
            System.exit(0);
        }

        if (size == 1 && index == 0) {
            clear();
        } else {
            if (index == 0) {
                header = header.getNext();
                size = size - 1;
            } else {
                int i = 0;
                Node p = header;
                while (p.getNext() != null) {
                    if (i + 1 == index) {
                        p.setNext((p.getNext()).getNext());
                        size = size - 1;
                        break;
                    } else {
                        p = p.getNext();
                        i = i + 1;
                    }
                }
            }
        }
    }

    //
    public int size() {
        return size;
    }

    //
    public ILinkedList sublist(int fromIndex, int toIndex) {
        SingleLinkedList sub = new SingleLinkedList();
        Node p = header;
        int i = 0;
        int temp;
        if (p == null || toIndex < fromIndex || toIndex < 0 || fromIndex < 0 || toIndex >= size || fromIndex >= size) {
            System.out.println("Error");
            System.exit(0);
        }
        while (p != null) {
            if (i == fromIndex)
                sub.header = p;
            if (i == toIndex) {
                sub.tail = p;
                temp = toIndex - fromIndex + 1;
                sub.size = temp;
                sub.tail.setNext(null);
                break;
            }
            p = p.getNext();
            i += 1;
        }
        return sub;
    }

    //
    public boolean contains(Object o) {
        boolean found = false;
        Node p = header;
        if (p == null) {
            System.out.println("Error");
            System.exit(0);
        }
        while (!found && p != null) {
            if (p.getElement() == o) {
                found = true;
            } else {
                p = p.getNext();
            }
        }
        if (found) {
            return true;
        } else {
            return false;
        }
    }

    public void display() {
        System.out.print("[");
        Node p = header;
        int i = 0;
        while (p != null) {
            System.out.print(p.getElement());
            i++;
            p = p.getNext();
            if (i < size) {
                System.out.print(", ");
            }
        }
        System.out.print("]");
    }
}

interface IPolynomialSolver {
/**
* Set polynomial terms (coefficients & exponents)
* @param poly: name of the polynomial
* @param terms: array of [coefficients][exponents]
*/
void setPolynomial(char poly, int[][] terms);
/**
* Print the polynomial in ordered human readable representation
* @param poly: name of the polynomial
* @return: polynomial in the form like 27x^2+x-1
*/
String print(char poly);
/**
* Clear the polynomial
* @param poly: name of the polynomial
*/
void clearPolynomial(char poly);
/**
* Evaluate the polynomial
* @param poly: name of the polynomial
* @param value: the polynomial constant value
* @return the value of the polynomial
*/
float evaluatePolynomial(char poly, float value);
/**
* Add two polynomials
* @param poly1: first polynomial
* @param poly2: second polynomial
* @return the result polynomial
*/
int[][] add(char poly1, char poly2);
/**
* Subtract two polynomials
* @param poly1: first polynomial
* @param poly2: second polynomial
* @return the result polynomial
*/
int[][] subtract(char poly1, char poly2);
/**
* Multiply two polynomials
* @param poly1: first polynomial
* @param poly2: second polynomial
* @return: the result polynomial
*/
int[][] multiply(char poly1, char poly2);
}


//public class PolynomialSolver implements IPolynomialSolver{
  //  public static void main(String[] args) {
    //    /* Enter your code here. Read input from STDIN. Print output to STDOUT. Your class should be named Solution. */
    //}
//}

class termNode {
    int coefficient;
    int exponent;

    termNode(int c, int e) {
        this.coefficient = c;
        this.exponent = e;
    }
}

class PolynomialSolver implements IPolynomialSolver {
    SingleLinkedList SLA;
    SingleLinkedList SLB;
    SingleLinkedList SLC;
    SingleLinkedList SLR;

    PolynomialSolver() {
        SLA = new SingleLinkedList();
        SLB = new SingleLinkedList();
        SLC = new SingleLinkedList();
        SLR = new SingleLinkedList();
    }

    public void setPolynomial(char poly, int[][] terms) {
        SingleLinkedList SL = null;
        switch (poly) {
        case 'A':
            SL = SLA;
            break;
        case 'B':
            SL = SLB;
            break;
        case 'C':
            SL = SLC;
            break;
        default:
            System.out.print("Error");
            System.exit(0);
        }
        try {
            for (int[] term : terms) {
                termNode t = new termNode(term[0], term[1]);
                SL.add(t);
            }
        } catch (Exception e) {
            System.out.print("Error");
            System.exit(0);
        }
        // now the Polynomial is set
    }

    public String print(char poly) {
        SingleLinkedList SL = null;
        switch (poly) {
        case 'A':
            SL = SLA;
            break;
        case 'B':
            SL = SLB;
            break;
        case 'C':
            SL = SLC;
            break;
        case 'R':
            SL = SLR;
            break;
        default:
            System.out.print("Error");
            System.exit(0);
        }

        String out = "";
        Node p = SL.header;
        if (p == null) {
            System.out.print("Error");
            System.exit(0);
        }
        int i = 0;
        boolean notfirstprint = false;
        try {
            while (p != null) {
                termNode temp = (termNode) p.getElement();
                if (temp.coefficient > 0 && notfirstprint)
                    out = out + ((temp.coefficient > 0) ? "+" : "");
                out = out + ((temp.coefficient < 0) ? "-" : "")
                        + ((temp.coefficient != 0)
                                ? ((temp.coefficient != 1 || temp.exponent == 0) ? Math.abs(temp.coefficient) : "")
                                        + ((temp.exponent >= 2) ? ("x^" + (temp.exponent))
                                                : ((temp.exponent == 1) ? ("x") : ("")))
                                : "");
                if (temp.coefficient != 0)
                    notfirstprint = true;
                i++;
                p = p.getNext();
            }
        } catch (Exception e) {
            System.out.print("Error");
            System.exit(0);
        }
        return out;
    }

    public void clearPolynomial(char poly) {
        SingleLinkedList SL = null;
        switch (poly) {
        case 'A':
            SL = SLA;
            break;
        case 'B':
            SL = SLB;
            break;
        case 'C':
            SL = SLC;
            break;
        default:
            System.out.print("Error");
            System.exit(0);
        }
        try {

            SL.clear();
            SL.display();
        } catch (Exception e) {
            System.out.print("Error");
            System.exit(0);
        }

    }

    public float evaluatePolynomial(char poly, float value) {
        SingleLinkedList SL = null;
        switch (poly) {
        case 'A':
            SL = SLA;
            break;
        case 'B':
            SL = SLB;
            break;
        case 'C':
            SL = SLC;
            break;
        case 'R':
            SL = SLR;
            break;
        default:
            System.out.print("Error");
            System.exit(0);
        }

        float result = 0f;
        try {
            Node p = SL.header;
            if (p == null) {
                System.out.print("Error");
                System.exit(0);
            }

            while (p != null) {
                termNode t = (termNode) p.getElement();
                result += t.coefficient * Math.pow(value, t.exponent);
                p = p.getNext();
            }
        } catch (Exception e) {
            System.out.print("Error");
            System.exit(0);
        }
        return result;
    }

    public int[][] add(char poly1, char poly2) {
        Node p;// traverse first
        Node q;// traverse second
        Node r;
        SingleLinkedList SL1 = null;
        SingleLinkedList SL2 = null;
        try {
            SLR.clear();
            switch (poly1) {
            case 'A':
                SL1 = SLA;
                break;
            case 'B':
                SL1 = SLB;
                break;
            case 'C':
                SL1 = SLC;
                break;
            default:
                System.out.print("Error");
                System.exit(0);
            }

            switch (poly2) {
            case 'A':
                SL2 = SLA;
                break;
            case 'B':
                SL2 = SLB;
                break;
            case 'C':
                SL2 = SLC;
                break;
            default:
                System.out.print("Error");
                System.exit(0);
            }
        } catch (Exception e) {
            System.out.print("Error");
            System.exit(0);
        }
        p = SL1.header;
        q = SL2.header;
        if (p == null || q == null) {
            System.out.print("Error");
            System.exit(0);
        }

        r = SLR.header;
        int i = 0;
        int j = 0;
        try {
            while (p != null && q != null) {
                termNode temp1 = (termNode) p.getElement();
                termNode temp2 = (termNode) q.getElement();
                if (temp1.exponent > temp2.exponent) // exp of 1 > exp of 2 ->> add node from 1 first
                {
                    termNode t = new termNode(temp1.coefficient, temp1.exponent);
                    SLR.add(t);
                    // now advance pointer and iterator of first List
                    i++;
                    p = p.getNext();
                } else if (temp1.exponent < temp2.exponent) {

                    termNode t = new termNode(temp2.coefficient, temp2.exponent);
                    SLR.add(t);
                    // now advance pointer and iterator of second List
                    j++;
                    q = q.getNext();
                } else {
                    // equal case
                    termNode t = new termNode(temp1.coefficient + temp2.coefficient, temp1.exponent);
                    SLR.add(t);
                    // now advance pointer and iterator of first List
                    i++;
                    j++;
                    p = p.getNext();
                    q = q.getNext();
                }
            }
            // when while loop is over
            // one of the two counters got to its end
            if (p == null)// reached end of first
            {
                while (q != null) {
                    termNode temp = (termNode) q.getElement();
                    termNode t = new termNode(temp.coefficient, temp.exponent);
                    SLR.add(t);
                    // now advance pointer and iterator of second List
                    j++;
                    q = q.getNext();
                }
            }
            if (q == null)// reached end of second
            {
                while (p != null) {
                    termNode temp = (termNode) p.getElement();
                    termNode t = new termNode(temp.coefficient, temp.exponent);
                    SLR.add(t);
                    // now advance pointer and iterator of first List
                    i++;
                    p = p.getNext();
                }

            }
        } catch (Exception e) {
            System.out.print("Error");
            System.exit(0);
        }
        r = SLR.header;
        int[][] res = new int[SLR.size()][2];
        i = 0;
        try {
            while (r != null) {
                termNode temp = (termNode) r.getElement();
                res[i][0] = temp.coefficient;
                res[i][1] = temp.exponent;
                i++;
                r = r.getNext();
            }
        } catch (Exception e) {
            System.out.print("Error");
            System.exit(0);
        }

        return res;
    }

    public int[][] subtract(char poly1, char poly2) {

        Node p;// traverse first
        Node q;// traverse second
        Node r;
        SingleLinkedList SL1 = null;
        SingleLinkedList SL2 = null;
        int i = 0;
        int j = 0;
        try {
            SLR.clear();
            switch (poly1) {
            case 'A':
                SL1 = SLA;
                break;
            case 'B':
                SL1 = SLB;
                break;
            case 'C':
                SL1 = SLC;
                break;
            default:
                System.out.print("Error");
                System.exit(0);
            }

            switch (poly2) {
            case 'A':
                SL2 = SLA;
                break;
            case 'B':
                SL2 = SLB;
                break;
            case 'C':
                SL2 = SLC;
                break;
            default:
                System.out.print("Error");
                System.exit(0);
            }

            p = SL1.header;
            q = SL2.header;
            if (p == null || q == null) {
                System.out.print("Error");
                System.exit(0);
            }
            r = SLR.header;

            while (p != null && q != null) {
                termNode temp1 = (termNode) p.getElement();
                termNode temp2 = (termNode) q.getElement();
                if (temp1.exponent > temp2.exponent) // exp of 1 > exp of 2 ->> add node from 1 first
                {
                    termNode t = new termNode(temp1.coefficient, temp1.exponent);
                    SLR.add(t);
                    // now advance pointer and iterator of first List
                    i++;
                    p = p.getNext();
                } else if (temp1.exponent < temp2.exponent) {

                    termNode t = new termNode(temp2.coefficient, temp2.exponent);
                    SLR.add(t);
                    // now advance pointer and iterator of second List
                    j++;
                    q = q.getNext();
                } else {
                    // equal case
                    termNode t = new termNode(temp1.coefficient - temp2.coefficient, temp1.exponent);
                    SLR.add(t);
                    // now advance pointer and iterator of first List
                    i++;
                    j++;
                    p = p.getNext();
                    q = q.getNext();
                }
            }
            // when while loop is over
            // one of the two counters got to its end
            if (p == null)// reached end of first
            {
                while (q != null) {
                    termNode temp = (termNode) q.getElement();
                    termNode t = new termNode(0 - temp.coefficient, temp.exponent);
                    SLR.add(t);
                    // now advance pointer and iterator of second List
                    j++;
                    q = q.getNext();
                }
            }
            if (q == null)// reached end of second
            {
                while (p != null) {
                    termNode temp = (termNode) p.getElement();
                    termNode t = new termNode(temp.coefficient, temp.exponent);
                    SLR.add(t);
                    // now advance pointer and iterator of first List
                    i++;
                    p = p.getNext();
                }

            }

        } catch (Exception e) {
            System.out.println("Error");
            System.exit(0);

        }
        r = SLR.header;
        int[][] res = new int[SLR.size()][2];
        i = 0;
        try {
            while (r != null) {
                termNode temp = (termNode) r.getElement();
                res[i][0] = temp.coefficient;
                res[i][1] = temp.exponent;
                i++;
                r = r.getNext();
            }
        } catch (Exception e) {
            System.out.println("Error");
            System.exit(0);
        }
        return res;

    }

    public int[][] multiply(char poly1, char poly2) {

        Node p;// traverse first
        Node q;// traverse second
        Node r;
        SingleLinkedList SL1 = null;
        SingleLinkedList SL2 = null;
        SLR.clear();
        switch (poly1) {
        case 'A':
            SL1 = SLA;
            break;
        case 'B':
            SL1 = SLB;
            break;
        case 'C':
            SL1 = SLC;
            break;
        default:
            System.out.print("Error");
            System.exit(0);
        }

        switch (poly2) {
        case 'A':
            SL2 = SLA;
            break;
        case 'B':
            SL2 = SLB;
            break;
        case 'C':
            SL2 = SLC;
            break;
        default:
            System.out.print("Error");
            System.exit(0);
        }

        p = SL1.header;
        q = SL2.header;
        if (p == null || q == null) {
            System.out.print("Error");
            System.exit(0);
        }
        int range = 0; // maximum size
        try {
            if (q != null && p != null) {
                termNode temp1 = (termNode) p.getElement();
                termNode temp2 = (termNode) q.getElement();
                range = temp1.exponent + temp2.exponent;
            }

            for (int i = range; i >= 0; i--) {
                termNode temp = new termNode(0, i);
                SLR.add(temp);
            }
        } catch (Exception e) {
            System.out.println("Error");
            System.exit(0);
        }
        // now we set up the space for the result
        termNode temp1;
        termNode temp2;
        termNode tempr;
        r = SLR.header;
        p = SL1.header;
        q = SL2.header;
        try {
            while (r != null) {
                tempr = (termNode) r.getElement();
                int temp = 0;
                while (p != null) {
                    temp1 = (termNode) p.getElement();
                    while (q != null) {
                        temp2 = (termNode) q.getElement();
                        if (temp1.exponent + temp2.exponent == tempr.exponent) {
                            temp += temp2.coefficient * temp1.coefficient;
                        }
                        q = q.getNext();

                    }
                    q = SL2.header;
                    p = p.getNext();
                }
                p = SL1.header;

                tempr.coefficient = temp;
                r = r.getNext();
            }
        } catch (Exception e) {
            System.out.println("Error");
            System.exit(0);
        }
    r = SLR.header;
        int[][] res = new int[SLR.size()][2];
        int i = 0;
        try {
            while (r != null) {
                termNode temp = (termNode) r.getElement();
                res[i][0] = temp.coefficient;
                res[i][1] = temp.exponent;
                i++;
                r = r.getNext();
            }
        } catch (Exception e) {
            System.out.println("Error");
            System.exit(0);
        }

        return res;
    }

}// end of class poly Solver
public class Solution {

    public static void main(String[] args) {
        PolynomialSolver poly = new PolynomialSolver();

        Scanner sc = new Scanner(System.in);
        // first input is the command
        while (sc.hasNext()) {
            String command = sc.next();
            sc.nextLine();
            char ch;
            char ch1;
            char ch2;

            // switch on the command
            switch (command) {
            case "add":
                ch1 = sc.next().charAt(0);
                sc.nextLine();
                ch2 = sc.next().charAt(0);
                poly.add(ch1, ch2);
                System.out.println(poly.print('R'));
                break;

            case "set":
                try {
                    String test = sc.nextLine();
                    ch = test.charAt(0);

                    String sin = sc.nextLine().replaceAll("\\[|\\]", "");
                    String[] s = sin.split(",");
                    int[][] arr = new int[s.length][2];
                    if (s.length == 1 && s[0].isEmpty()) {
                        System.out.println("Error");
                        System.exit(0);
                    } else {
                        int j = 0;
                        while (j < s.length) {
                            if (s[j].isEmpty() || sin.charAt(sin.length() - 1) == ',' || sin.contains(" ")) {
                                System.out.println("Error");
                                System.exit(0);
                            }
                            j++;
                        }

                        for (int i = 0; i < s.length; ++i) {
                            arr[i][0] = Integer.parseInt(s[i]);
                            arr[i][1] = s.length - i - 1;
                        }
                    }
                    poly.setPolynomial(ch, arr);
                    break;
                } catch (Exception e) {
                    System.out.println("Error");
                    System.exit(0);
                }

            case "sub":
                ch1 = sc.next().charAt(0);
                sc.nextLine();
                ch2 = sc.next().charAt(0);
                poly.subtract(ch1, ch2);
                System.out.println(poly.print('R'));
                break;

            case "eval":
                ch = sc.next().charAt(0);
                sc.nextLine();
                float in = sc.nextFloat();
                float out = poly.evaluatePolynomial(ch, in);
                if (out - (int) out == 0.0)
                    System.out.println((int) out);
                else
                    System.out.println((out));

                break;

            case "clear":
                ch = sc.next().charAt(0);
                poly.clearPolynomial(ch);
                break;

            case "mult":
                ch1 = sc.next().charAt(0);
                sc.nextLine();
                ch2 = sc.next().charAt(0);
                poly.multiply(ch1, ch2);
                System.out.println(poly.print('R'));
                break;

            case "print":
                ch = sc.next().charAt(0);
                System.out.println(poly.print(ch));
                break;

            default:
                System.out.println("Error");
                System.exit(0);
            }

        }

    }
}

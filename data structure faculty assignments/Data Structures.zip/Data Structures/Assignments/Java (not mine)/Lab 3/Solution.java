import java.io.*;
import java.util.*;
import java.text.*;
import java.math.*;
import java.util.regex.*;
import java.awt.Point;



interface IPlayersFinder {

    /**
     * Search for players locations at the given photo
     * @param photo
     *     Two dimension array of photo contents
     *     Will contain between 1 and 50 elements, inclusive
     * @param team
     *     Identifier of the team
     * @param threshold
     *     Minimum area for an element
     *     Will be between 1 and 10000, inclusive
     * @return
     *     Array of players locations of the given team
     */
    java.awt.Point[] findPlayers(String[] photo, int team, int threshold);
}



//to store the current shape 
class Shape{
    int minX;
    int maxX;
    int minY;
    int maxY;
    Shape(int a, int b, int c , int d)
    {
        minX=a;
        maxX=b;
        minY=c;
        maxY=d;
    }
}

public class Solution implements IPlayersFinder  {
    
    public java.awt.Point[] findPlayers(String[] photo, int team, int threshold)
    {
        
        java.awt.Point[] finUnsorted = new java.awt.Point[150];
        ArrayList<java.awt.Point> checked= new ArrayList<>();
        int counter=0;
        //convert to 2d array of characters
        char[][] photo2D= new char[photo.length][photo[0].length()];
        for(int i = 0 ; i < photo.length ; i++)
        {
            photo2D[i]=photo[i].toCharArray();
        }
        for(int i=0;i<photo2D.length;i++)
        {
            for (int j=0;j<photo2D[0].length;j++)
            {
                if(team + '0' == photo2D[i][j]){
                    Shape current=new Shape(2*j,2*j+2,2*i,2*i+2);
                    
                    if(findArea(j,i,photo2D,team,current,checked)>=threshold)
                    {
                        
                        //code that stores the point inside
                        finUnsorted[counter]=new Point((current.minX+current.maxX)/2, (current.minY+current.maxY)/2);
                        counter++;
                    }                    
                }            
            }
        }
        
        Arrays.sort(finUnsorted,0,counter, new Comparator<Point>() {
             public int compare(Point a, Point b) {
                int xComp = Integer.compare(a.x, b.x);
                if(xComp == 0)
                    return Integer.compare(a.y, b.y);
                else
                    return xComp;
            }
        });
       
        return finUnsorted;
    }
    
    
    public int findArea(int x,int y,char[][] photo2D, int team, Shape current,ArrayList<Point> checked)
    {
        
        java.awt.Point p=new java.awt.Point(x,y);
        
        //x and y are coordinates in the 2d array not real locations
        if ((photo2D[y][x]!= team + '0')||(checked.contains(p)))
            return 0;
        else 
        {
            checked.add(p);
            //setup corners
            if(2*x+2>current.maxX)
                current.maxX=2*x+2;
            if(2*x<current.minX)
                current.minX=2*x;
            if(2*y<current.minY)
                current.minY=2*y;
            if(2*y+2>current.maxY)
                current.maxY=2*y+2;
    
            int left,right,down,up;
            left=right=down=up=0;
            if(y-1>=0)
            {
                up = findArea(x,y-1,photo2D,team,current,checked);
            }
            if(x-1>=0)
            {
                left = findArea(x-1,y,photo2D,team,current,checked);       
            }
                
            if(x+1<photo2D[0].length)
            {
                right = findArea(x+1,y,photo2D,team,current,checked);
            }
                
            if(y+1<photo2D.length)
            {
                down = findArea(x,y+1,photo2D,team,current,checked);
            }
                
            
            return (4+down+left+right+up);
        }
        
    }
    
    
    public static void main(String[] args) {
        Scanner sc= new Scanner(System.in);
        String dim[]= sc.nextLine().split(", ");
        int dimInt[]= new int[2];
        int i=0;
        for(String s:dim)
        {
            dimInt[i++]=Integer.parseInt(s);
        }
        //dimInt[0] is rows
        //dimInt[1] is cols
        String[] photo= new String[dimInt[0]];
        for(i=0;i<dimInt[0];i++)
        {
            photo[i]=sc.nextLine();
        }
        int team = sc.nextInt();
        sc.nextLine();
        int threshold= sc.nextInt();
        
        Solution s = new Solution();
        System.out.print("[");
             if(dimInt[0]!=0 && dimInt[1]!=0 )
            {
            Point[] arr ; 
            arr = s.findPlayers(photo,team,threshold);
            
            if(arr!=null)
            {
                
                for (int k =0 ; k< arr.length && arr[k]!=null; k++)
                {
                    System.out.print("(");
                    System.out.print(arr[k].x + ", " + arr[k].y );
                    System.out.print(")");
                    if(arr[k+1]!=null)
                        System.out.print(", ");
                }
               
            } 
            }
        
             System.out.print("]");
        
    }
}





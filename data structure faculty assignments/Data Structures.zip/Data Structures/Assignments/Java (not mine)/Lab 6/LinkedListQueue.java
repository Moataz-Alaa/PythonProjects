import java.io.*;
import java.util.*;
import java.text.*;
import java.math.*;
import java.util.regex.*;

interface IQueue {
  /*** Inserts an item at the queue front.*/
  public void enqueue(Object item);
  /*** Removes the object at the queue rear and returnsit.*/
  public Object dequeue();
  /*** Tests if this queue is empty.*/
  public boolean isEmpty();
  /*** Returns the number of elements in the queue*/
  public int size();
}

public class LinkedListQueue implements IQueue {

    public static void main(String[] args) {
  LinkedListQueue q = new LinkedListQueue();
  Scanner input = new Scanner(System.in);
  String list = input.nextLine().replaceAll("\\[|\\]", "");
      String[] s = list.split(", ");
      try {
          if (!s[0].isEmpty()) {
              for (int i = s.length - 1; i >= 0; --i) {
                  q.enqueue(Integer.parseInt(s[i]));
              }
          }

          String op = input.nextLine();
          switch (op) {
              case "enqueue":
                  q.enqueue(input.nextInt());
                  q.display();
                  break;
              case "dequeue":
                  q.dequeue();
                  q.display();
                  break;
              case "isEmpty":
                  if (q.isEmpty() == false)
                      System.out.println("False");
                  else
                      System.out.println("True");
                  break;
              case "size":
                  System.out.println(q.size);
                  break;
              default:
                  System.out.println("Error");
          }
      }catch (RuntimeException w){
          System.out.println("Error");
      }
    }
  class Node {
        int data;
        Node next;
       public Node(int d)
        {
            this.data = d;
            this.next = null;
        }
    }
    Node front , rear ;
    int size ;
    public  LinkedListQueue(){
        front = null ;
        rear= null;
        size = 0 ;
    }

    public void enqueue(Object item) {
        Node n = new Node((int)item);
        if (isEmpty()){
            front = n ;
            rear = n ;
        }
        else {
            rear.next = n;
            rear = n;
        }
        size++ ;
    }

    public Object dequeue() {
   if (front == null) {
       throw new RuntimeException();
   }
    Node tmp = front;
    front = front.next;
    size--;
    if(front==null){
      rear = null ;
    }
        return null;
    }

    public boolean isEmpty() {
        if (front == null && rear == null ){
            return true;
        }
        else
        return false;
    }

    public int size() {
        return size;
    }
    public void display(){
        int [] arr = new int[size] ;
        int i = 0;
        Node current = front ;
        while(current != null){
            arr[i]=current.data;
            current= current.next;
            i++;
        }
        System.out.print("[");
        for(int j= size-1;j>=0 ; j-- ){
            if(j!=0) {
                System.out.print(arr[j] + ", ");
            }
            else
                System.out.print(arr[j]);
        }
        System.out.print("]");
    }
}


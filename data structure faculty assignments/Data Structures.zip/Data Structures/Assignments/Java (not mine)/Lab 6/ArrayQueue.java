import java.io.*;
import java.util.*;
import java.text.*;
import java.math.*;
import java.util.regex.*;

interface IQueue {
  /*** Inserts an item at the queue front.*/
  public void enqueue(Object item);
  /*** Removes the object at the queue rear and returnsit.*/
  public Object dequeue();
  /*** Tests if this queue is empty.*/
  public boolean isEmpty();
  /*** Returns the number of elements in the queue*/
  public int size();
}

public class ArrayQueue implements IQueue {
private static final int MAX = 100;
    Object[] Q;
    private int rear;
    private int front;
    private int N;
    private int size; // counter for the size of the Q

    ArrayQueue(int sizeMax) {
        Q = new Object[sizeMax];
        N = sizeMax;
        rear = 0;
        front = 0;
        size = 0;
    }

    ArrayQueue() {
        Q = new Object[MAX];
        N = MAX;
        rear = 0;
        front = 0;
        size = 0;
    }

    public void enqueue(Object item) {
        // rear is after the last element
        if (size == N)
            throw new RuntimeException();
        Q[rear] = item;
        rear = (rear + 1) % N;
        size = size + 1;
    }

    public Object dequeue() {
        if (isEmpty())
            throw new RuntimeException();
        Object out = Q[front];
        size = size - 1;
        front = (front + 1) % N;
        return out;
    }

    public boolean isEmpty() {
        return size == 0;
    }

    public int size() {
        return size;
    }

    public String stringOut() {
        String out = "[";
        Object[] temp = new Object[size]; // for reversing
        for (int i = 0; i < size; i++) {
            temp[i] = Q[i + front];
        }
        for (int i = size - 1; i >= 0; i--) {
            out = out + temp[i];
            if (i != 0)
                out = out + ", ";
        }
        out = out + "]";

        return out;
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String input = sc.nextLine().replaceAll("\\[|\\]", "");
        String command = sc.next();

        String[] s = input.split(", ");
        // code can be modified so that the user can enter the max no. in Q
        ArrayQueue Q = new ArrayQueue(MAX);
        try {

            if (!(s.length == 1 && s[0].isEmpty())) {
                for (int i = s.length - 1; i >= 0; --i)
                    Q.enqueue(Integer.parseInt(s[i]));
            }
        } catch (RuntimeException r) {
            System.out.println("Error");
            System.exit(0);
        }

        switch (command) {
        case "enqueue":
            int in = sc.nextInt();
            try {
                Q.enqueue(in);
                System.out.println(Q.stringOut());
            } catch (RuntimeException r) {
                System.out.println("Error");
            }
            break;
        case "dequeue":
            try {
                Q.dequeue();
                System.out.println(Q.stringOut());
            } catch (RuntimeException r) {
                System.out.println("Error");
            }
            break;
        case "size":
            System.out.println(Q.size);
            break;
        case "isEmpty":
            if (Q.isEmpty())
                System.out.println("True");
            else
                System.out.println("False");
            break;
        default:
            System.out.println("Error");

        }

    }
}